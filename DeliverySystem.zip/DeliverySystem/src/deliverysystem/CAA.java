/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deliverysystem;

/**
 *
 * @author  Ama
 */
public class CAA {
    private long Contact;
    private String Name,CompleteAddress,Product,ShopName,ShopOwner,ShopLocation,ShippingDate,ToArrived;
    public CAA (String Name,String CompleteAddress,long Contact,String Product,String ShopName,String ShopOwner,String ShopLocation,String ShippingDate,String ToArrived){
        this.Name = Name;
        this.CompleteAddress = CompleteAddress;
        this.Contact=Contact;
        this.Product=Product;
        this.ShopName=ShopName;
        this.ShopOwner=ShopOwner;
        this.ShopLocation=ShopLocation;
        this.ShippingDate=ShippingDate;
        this.ToArrived=ToArrived;
        
     }

    CAA(String string, String string0, long aLong, String string1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    CAA(String string, String string0, long aLong, String string1, String string2) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    public String getName(){
        return  Name;
    }
   public String getCompleteAddress(){
        return  CompleteAddress;
    }
    public long getContact(){
        return  Contact;
    }
     public String getProd(){
        return  Product;
    }
     public String getShopName(){
        return  ShopName;
    }
     public String getShopOwner(){
        return  ShopOwner;
    }
     public String getShopLocation(){
        return  ShopLocation;
    }
     public String getShippingDate(){
        return  ShippingDate;
    }
     public String getToArrived(){
        return  ToArrived;
    }
    
}
